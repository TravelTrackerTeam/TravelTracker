# models.py
from extensions import mongo, bcrypt
from bson import ObjectId

class UserModel:
    @staticmethod
    def find_by_email(email):
        return mongo.db.users.find_one({"email": email})

    @staticmethod
    def create_user(username, email, password):
        hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')
        return mongo.db.users.insert_one({
            "username": username,
            "email": email,
            "password": hashed_pw,
            "trips": []
        })

    @staticmethod
    def verify_password(user, password):
        return bcrypt.check_password_hash(user["password"], password)

class TripModel:
    @staticmethod
    def get_trips(user_id):
        user = mongo.db.users.find_one({"_id": ObjectId(user_id)})
        return user.get("trips", [])

    @staticmethod
    def add_trip(user_id, trip_data):
        mongo.db.users.update_one(
            {"_id": ObjectId(user_id)},
            {"$push": {"trips": trip_data}}
        )

    @staticmethod
    def delete_trip(user_id, title):
        mongo.db.users.update_one(
            {"_id": ObjectId(user_id)},
            {"$pull": {"trips": {"title": title}}}
        )









