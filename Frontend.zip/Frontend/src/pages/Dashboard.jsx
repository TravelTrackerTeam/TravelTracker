import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import AddTripModal from "../components/AddTripModal";
import TripCard from "../components/TripCard";
import API from "../services/api";
import "../styles/theme.css";

export default function Dashboard() {
  const [trips, setTrips] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const fetchTrips = async () => {
    try {
      const res = await API.get("/trips");
      setTrips(res.data);
    } catch (err) {
      console.error("Failed to fetch trips", err);
    }
  };

  useEffect(() => {
    fetchTrips();
  }, []);

  const handleAddTrip = async (tripData) => {
    try {
      const res = await API.post("/trips", tripData);
      // 👇 fallback ID + empty expenses if not returned
      const newTrip = {
        ...tripData,
        _id: res.data._id || Date.now().toString(),
        expenses: [],
      };
      setTrips([...trips, newTrip]);
      setShowModal(false);
    } catch (err) {
      console.error("Failed to add trip", err);
    }
  };

  const handleDeleteTrip = async (tripId) => {
    try {
      await API.delete(`/trips/${tripId}`);
      setTrips(trips.filter((trip) => trip._id !== tripId));
    } catch (err) {
      console.error("Failed to delete trip", err);
    }
  };

  const handleAddExpense = async (tripId, expense) => {
    try {
      const res = await API.post(`/trips/${tripId}/expenses`, expense);
      setTrips(
        trips.map((trip) =>
          trip._id === tripId ? res.data : trip
        )
      );
    } catch (err) {
      console.error("Failed to add expense", err);
    }
  };

  return (
    <div className="page">
      <Navbar />

      <h1 className="page-title">My Trips</h1>

      <div className="controls">
        <button className="button-add-trip" onClick={() => setShowModal(true)}>
          + Add Trip
        </button>
      </div>

      {showModal && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <h2 className="modal-title">Create New Trip</h2>
            <AddTripModal onAddTrip={handleAddTrip} onClose={() => setShowModal(false)} />
          </div>
        </div>
      )}

      {trips.length === 0 ? (
        <p style={{ textAlign: "center", marginTop: "50px" }}>
          No trips yet! Click 'Add Trip' to get started ✈️
        </p>
      ) : (
        <div className="trip-list">
          {trips.map((trip) => (
            <TripCard
              key={trip._id}
              trip={trip}
              onDelete={() => handleDeleteTrip(trip._id)}
              onAddExpense={(expense) => handleAddExpense(trip._id, expense)}
            />
          ))}
        </div>
      )}
    </div>
  );
}





























