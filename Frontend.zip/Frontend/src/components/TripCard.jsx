import { useState, useEffect } from "react";
import AddExpenseForm from "./AddExpenseForm";
import CurrencySwitcher from "./CurrencySwitcher";

export default function TripCard({ trip, onDelete, onAddExpense }) {
  const [selectedCurrency, setSelectedCurrency] = useState(trip.currency);
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [exchangeRates, setExchangeRates] = useState({});

  useEffect(() => {
    fetchRates(trip.currency);
  }, [trip.currency]);

  const fetchRates = async (currency) => {
    try {
      const res = await fetch(`https://api.exchangerate-api.com/v4/latest/${currency}`);
      const data = await res.json();
      setExchangeRates(data.rates);
    } catch (err) {
      console.error("Failed to fetch rates", err);
    }
  };

  const convertAmount = (amount) => {
    if (typeof amount !== "number" || isNaN(amount)) return "0.00";
    if (selectedCurrency === trip.currency || !exchangeRates[selectedCurrency]) return amount.toFixed(2);
    const base = amount / exchangeRates[trip.currency];
    return (base * exchangeRates[selectedCurrency]).toFixed(2);
  };

  const budget = trip.budget || 0;
  const expenses = Array.isArray(trip.expenses) ? trip.expenses : [];
  const totalSpent = expenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);
  const remaining = budget - totalSpent;

  return (
    <div className="trip-card">
      <h2 className="trip-title">{trip.title}</h2>
      <p><strong>Budget:</strong> {selectedCurrency} {convertAmount(budget)}</p>
      <p><strong>Spent:</strong> {selectedCurrency} {convertAmount(totalSpent)}</p>
      <p className={remaining < 0 ? "over-budget" : "under-budget"}>
        <strong>Remaining:</strong> {selectedCurrency} {convertAmount(remaining)}
      </p>

      {expenses.length > 0 && (
        <div className="trip-expenses">
          {expenses.map((expense, idx) => (
            <div key={`${expense.name}-${idx}`} className="expense-item">
              <span>{expense.name}</span>
              <span>{selectedCurrency} {convertAmount(expense.amount)}</span>
            </div>
          ))}
        </div>
      )}

      <div className="trip-buttons">
        <button className="button-edit" onClick={() => setShowExpenseForm(true)}>+ Add Expense</button>
        <button className="button-delete" onClick={onDelete}>Delete Trip</button>
      </div>

      {showExpenseForm && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <h3 className="modal-title">Add Expense</h3>
            <AddExpenseForm
              onAdd={(expense) => {
                onAddExpense(expense);
                setShowExpenseForm(false);
              }}
              onClose={() => setShowExpenseForm(false)}
            />
          </div>
        </div>
      )}

      <div className="currency-section">
        <CurrencySwitcher
          currency={selectedCurrency}
          onCurrencyChange={(newCurrency) => {
            setSelectedCurrency(newCurrency);
            fetchRates(newCurrency);
          }}
        />
      </div>
    </div>
  );
}











